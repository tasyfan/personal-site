const canvas = document.querySelector("#fx");
const ctx = canvas.getContext("2d", { alpha: true });

const colors = ["#4285f4", "#ea4335", "#fbbc04", "#34a853"];
const darkColors = ["#8a4fff", "#00f0ff", "#ffd54f", "#ffffff", "#88c8f7", "#b4a0e5"];

const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const coarsePointer = window.matchMedia("(pointer: coarse)").matches;
const state = {
  frame: 0,
  particles: [],
  ripples: [],
  pointer: { x: innerWidth * 0.5, y: innerHeight * 0.5 },
  running: true,
  lastTouchAt: 0,
};

function isCompactViewport() {
  return innerWidth <= 768 || coarsePointer;
}

function getMaxParticles() {
  if (reduceMotion) return 36;
  return isCompactViewport() ? 120 : 280;
}

const DPR_LIMIT = 1.25;

function isDarkMode() {
  return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
}

function resize() {
  const dpr = Math.min(devicePixelRatio || 1, DPR_LIMIT);
  canvas.width = Math.floor(innerWidth * dpr);
  canvas.height = Math.floor(innerHeight * dpr);
  canvas.style.width = `${innerWidth}px`;
  canvas.style.height = `${innerHeight}px`;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function spawn(x, y, amount = 1, force = 1, isAmbient = false) {
  const room = getMaxParticles() - state.particles.length;
  const count = Math.max(0, Math.min(amount, room));
  const currentColors = isDarkMode() ? darkColors : colors;

  for (let i = 0; i < count; i += 1) {
    const angle = Math.random() * Math.PI * 2;
    const speed = (0.08 + Math.random() * 0.45) * force;
    state.particles.push({
      x,
      y,
      originX: x,
      originY: y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      age: 0,
      life: isAmbient ? Infinity : (180 + Math.random() * 200),
      size: 0.6 + Math.random() * 2.0,
      color: currentColors[Math.floor(Math.random() * currentColors.length)],
      twinkle: Math.random() * Math.PI * 2,
      twinkleSpeed: 0.02 + Math.random() * 0.04
    });
  }
}

function seed() {
  state.particles = [];
  const amount = reduceMotion ? 24 : (isCompactViewport() ? 70 : 180);
  for (let i = 0; i < amount; i += 1) {
    spawn(Math.random() * innerWidth, Math.random() * innerHeight, 1, 0.1, true);
  }
}

function getDisplacedPoint(x, y) {
  if (reduceMotion) return { x, y };

  let dx = state.pointer.x - x;
  let dy = state.pointer.y - y;
  let dist = Math.sqrt(dx * dx + dy * dy);
  
  let targetX = x;
  let targetY = y;

  // 1. Mouse gravity indentation (distorts grid inwards)
  const gravityRadius = isCompactViewport() ? 160 : 200;
  if (dist < gravityRadius && dist > 0.1) {
    const pull = Math.pow(1 - dist / gravityRadius, 2) * (isCompactViewport() ? 10 : 16);
    targetX += (dx / dist) * pull;
    targetY += (dy / dist) * pull;
  }

  // 2. Gravitational wave ripples distortion (push outward)
  for (const ripple of state.ripples) {
    const rdx = x - ripple.x;
    const rdy = y - ripple.y;
    const rdist = Math.sqrt(rdx * rdx + rdy * rdy);
    
    const waveFrontThickness = 50;
    const diff = Math.abs(rdist - ripple.radius);
    if (diff < waveFrontThickness) {
      const waveForce = (1 - diff / waveFrontThickness) * ripple.alpha * 15;
      if (rdist > 0.1) {
        targetX += (rdx / rdist) * waveForce;
        targetY += (rdy / rdist) * waveForce;
      }
    }
  }

  return { x: targetX, y: targetY };
}

function drawGravityGrid() {
  if (reduceMotion) return;
  const spacing = isCompactViewport() ? 86 : 60;
  const cols = Math.ceil(innerWidth / spacing) + 1;
  const rows = Math.ceil(innerHeight / spacing) + 1;
  const dark = isDarkMode();
  
  ctx.strokeStyle = dark ? "rgba(0, 240, 255, 0.04)" : "rgba(66, 133, 244, 0.04)";
  ctx.lineWidth = 0.5;

  // Draw horizontal rows
  for (let r = 0; r < rows; r++) {
    ctx.beginPath();
    for (let c = 0; c < cols; c++) {
      const gx = c * spacing;
      const gy = r * spacing;
      const disp = getDisplacedPoint(gx, gy);
      if (c === 0) ctx.moveTo(disp.x, disp.y);
      else ctx.lineTo(disp.x, disp.y);
    }
    ctx.stroke();
  }

  // Draw vertical columns
  for (let c = 0; c < cols; c++) {
    ctx.beginPath();
    for (let r = 0; r < rows; r++) {
      const gx = c * spacing;
      const gy = r * spacing;
      const disp = getDisplacedPoint(gx, gy);
      if (r === 0) ctx.moveTo(disp.x, disp.y);
      else ctx.lineTo(disp.x, disp.y);
    }
    ctx.stroke();
  }
}

function drawParticle(particle) {
  const alpha = Math.max(0, 1 - particle.age / particle.life);
  const pulse = 0.5 + Math.sin(particle.twinkle) * 0.5;
  ctx.globalAlpha = alpha * pulse * (isDarkMode() ? 0.85 : 0.6);
  ctx.fillStyle = particle.color;
  ctx.beginPath();
  ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
  ctx.fill();
}

function updateAutoPointer() {
  if (!isCompactViewport() || reduceMotion) return;
  const time = state.frame * 0.012;
  const centerX = innerWidth * 0.5;
  const centerY = innerHeight * 0.42;
  const radiusX = Math.min(innerWidth * 0.26, 110);
  const radiusY = Math.min(innerHeight * 0.12, 90);
  state.pointer.x = centerX + Math.cos(time) * radiusX + Math.sin(time * 0.47) * 24;
  state.pointer.y = centerY + Math.sin(time * 0.82) * radiusY;

  if (state.frame % 120 === 0 && state.ripples.length < 2) {
    state.ripples.push({
      x: state.pointer.x,
      y: state.pointer.y,
      radius: 4,
      maxRadius: 150,
      speed: 2.4,
      alpha: 1.0
    });
  }
}

function tick() {
  if (!state.running) return;
  if (document.documentElement.classList.contains("antigravity-ready")) {
    ctx.clearRect(0, 0, innerWidth, innerHeight);
    state.running = false;
    return;
  }

  state.frame += 1;
  updateAutoPointer();
  ctx.clearRect(0, 0, innerWidth, innerHeight);
  ctx.globalCompositeOperation = "source-over";

  const dark = isDarkMode();

  // 1. Draw space-time gravity grid (behaves like Google Antigravity grid)
  drawGravityGrid();

  // 2. Draw and update expanding gravitational wave ripples
  state.ripples = state.ripples.filter(ripple => {
    ripple.radius += ripple.speed;
    ripple.alpha = 1 - (ripple.radius / ripple.maxRadius);
    
    ctx.strokeStyle = dark ? `rgba(0, 240, 255, ${ripple.alpha * 0.15})` : `rgba(66, 133, 244, ${ripple.alpha * 0.1})`;
    ctx.lineWidth = 1.0;
    ctx.beginPath();
    ctx.arc(ripple.x, ripple.y, ripple.radius, 0, Math.PI * 2);
    ctx.stroke();

    return ripple.radius < ripple.maxRadius;
  });

  // 3. Draw constellation lines connecting particles
  if (!reduceMotion && state.particles.length > 1 && !isCompactViewport()) {
    ctx.lineWidth = dark ? 0.5 : 0.4;
    for (let i = 0; i < state.particles.length; i += 1) {
      for (let j = i + 1; j < state.particles.length; j += 1) {
        const p1 = state.particles[i];
        const p2 = state.particles[j];
        const dx = p1.x - p2.x;
        const dy = p1.y - p2.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        const limit = dark ? 100 : 80;
        if (dist < limit) {
          const alpha = (1 - dist / limit) * 0.22;
          ctx.globalAlpha = alpha;
          ctx.strokeStyle = dark ? "rgba(0, 240, 255, 0.25)" : "rgba(66, 133, 244, 0.18)";
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
        }
      }
    }
  }

  if (!reduceMotion && state.frame % (isCompactViewport() ? 12 : 6) === 0) {
    const centerX = innerWidth * 0.5;
    const centerY = innerHeight * 0.42;
    const radius = Math.min(innerWidth, innerHeight) * (0.2 + Math.random() * 0.26);
    const angle = performance.now() * 0.0001 + Math.random() * Math.PI * 2;
    spawn(centerX + Math.cos(angle) * radius, centerY + Math.sin(angle) * radius * 0.42, 1, 0.3);
  }

  // 4. Update and filter particles
  state.particles = state.particles.filter((particle) => {
    particle.age += 1;
    particle.twinkle += particle.twinkleSpeed;
    
    // Calculate a slow, drifting target position around its origin coordinates (Micro-oscillation)
    // We use the particle's unique twinkle value as a phase offset so they drift out of sync
    const driftRadius = particle.life === Infinity ? 12 : 0; // Only ambient background stars drift!
    const driftSpeed = 0.008;
    const driftX = particle.originX + Math.sin(state.frame * driftSpeed + particle.twinkle) * driftRadius;
    const driftY = particle.originY + Math.cos(state.frame * driftSpeed + particle.twinkle) * driftRadius;

    // Restoring spring force towards this drifting home position
    const homeDx = driftX - particle.x;
    const homeDy = driftY - particle.y;
    let restoreStrength = 0.015;

    // Pointer gravity and orbital constraint creating a perfect flowing circle centered at the mouse
    if (state.pointer.x && state.pointer.y) {
      const dx = particle.x - state.pointer.x; // Vector from pointer to particle
      const dy = particle.y - state.pointer.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      
      const pointerRadius = isCompactViewport() ? 190 : 260;
      if (dist < pointerRadius && dist > 2) {
        const nx = dx / dist;
        const ny = dy / dist;
        
        // Target orbital circle radius around the cursor
        const targetR = isCompactViewport() ? 54 : 70;
        const diff = dist - targetR;
        
        const influence = Math.pow(1 - dist / pointerRadius, 1.5);
        
        // Radial force (spring pull/push towards targetR)
        const radialForce = -diff * 0.06 * influence; 
        
        // Tangential orbital velocity (swirling rotation) - EVEN SLOWER for calm, elegant drift!
        const swirlSpeed = 0.003;
        const tx = -ny * swirlSpeed;
        const ty = nx * swirlSpeed;

        particle.vx += nx * radialForce + tx;
        particle.vy += ny * radialForce + ty;

        // Dampen home restoring force when mouse influence is strong
        restoreStrength *= (1 - influence);
      }
    }

    // Apply restoring force
    particle.vx += homeDx * restoreStrength;
    particle.vy += homeDy * restoreStrength;

    particle.x += particle.vx;
    particle.y += particle.vy;
    // Friction to stabilize and dampen spring oscillation
    particle.vx *= 0.94;
    particle.vy *= 0.94;

    drawParticle(particle);

    return (particle.life === Infinity || particle.age < particle.life) && particle.x > -40 && particle.x < innerWidth + 40 && particle.y > -40 && particle.y < innerHeight + 40;
  });

  window.__particleCount = state.particles.length;

  requestAnimationFrame(tick);
}

window.addEventListener("resize", () => {
  resize();
  seed();
});

function moveGravityPoint(clientX, clientY, options = {}) {
  // Calculate distance moved to trigger gravitational wave ripples
  const dx = clientX - state.pointer.x;
  const dy = clientY - state.pointer.y;
  const dist = Math.sqrt(dx * dx + dy * dy);

  state.pointer.x = clientX;
  state.pointer.y = clientY;

  // Trigger ripple if moved significantly and ripple limit is not exceeded
  const rippleLimit = isCompactViewport() ? 3 : 6;
  const rippleMinDistance = isCompactViewport() ? 28 : 18;
  if (options.ripple !== false && dist > rippleMinDistance && state.ripples.length < rippleLimit) {
    state.ripples.push({
      x: clientX,
      y: clientY,
      radius: 4,
      maxRadius: isCompactViewport() ? 170 : 240,
      speed: isCompactViewport() ? 2.8 : 3.5,
      alpha: 1.0
    });
  }

  const spawnEvery = isCompactViewport() ? 4 : 2;
  if (!reduceMotion && options.spawn !== false && state.frame % spawnEvery === 0) {
    const angle1 = Math.random() * Math.PI * 2;
    const angle2 = angle1 + Math.PI; // Balanced spawn on opposite sides
    const r = isCompactViewport() ? 52 : 70;
    spawn(clientX + Math.cos(angle1) * r, clientY + Math.sin(angle1) * r, 1, isCompactViewport() ? 0.28 : 0.4);
    if (!isCompactViewport()) {
      spawn(clientX + Math.cos(angle2) * r, clientY + Math.sin(angle2) * r, 1, 0.4);
    }
  }
}

window.addEventListener("pointermove", (event) => {
  if (isCompactViewport()) return;
  if (event.pointerType === "touch" && Date.now() - state.lastTouchAt < 80) return;
  moveGravityPoint(event.clientX, event.clientY);
});

window.addEventListener("touchstart", (event) => {
  if (isCompactViewport()) return;
  const touch = event.touches && event.touches[0];
  if (!touch) return;
  state.lastTouchAt = Date.now();
  moveGravityPoint(touch.clientX, touch.clientY, { ripple: true, spawn: true });
}, { passive: true });

window.addEventListener("touchmove", (event) => {
  if (isCompactViewport()) return;
  const touch = event.touches && event.touches[0];
  if (!touch) return;
  state.lastTouchAt = Date.now();
  moveGravityPoint(touch.clientX, touch.clientY, { ripple: true, spawn: true });
}, { passive: true });

window.__northstarFx = {
  getState() {
    return {
      particles: state.particles.length,
      ripples: state.ripples.length,
      pointer: { ...state.pointer },
      compact: isCompactViewport()
    };
  },
  moveGravityPoint
};

document.addEventListener("visibilitychange", () => {
  state.running = !document.hidden;
  if (state.running) requestAnimationFrame(tick);
});

resize();
seed();
requestAnimationFrame(tick);
