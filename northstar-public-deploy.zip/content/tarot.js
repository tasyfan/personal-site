window.TAROT_DATA = {
  "cards": {
    "0": {
      "name": "愚者",
      "upright": "",
      "reversed": ""
    },
    "1": {
      "name": "魔术师",
      "upright": "",
      "reversed": ""
    },
    "2": {
      "name": "女祭司",
      "upright": "",
      "reversed": ""
    },
    "3": {
      "name": "女皇",
      "upright": "",
      "reversed": ""
    },
    "4": {
      "name": "皇帝",
      "upright": "",
      "reversed": ""
    },
    "5": {
      "name": "教皇",
      "upright": "",
      "reversed": ""
    },
    "6": {
      "name": "恋人",
      "upright": "",
      "reversed": ""
    },
    "7": {
      "name": "战车",
      "upright": "",
      "reversed": ""
    },
    "8": {
      "name": "力量",
      "upright": "",
      "reversed": ""
    },
    "9": {
      "name": "隐士",
      "upright": "",
      "reversed": ""
    },
    "10": {
      "name": "命运之轮",
      "upright": "",
      "reversed": ""
    },
    "11": {
      "name": "正义",
      "upright": "",
      "reversed": ""
    },
    "12": {
      "name": "倒吊人",
      "upright": "",
      "reversed": ""
    },
    "13": {
      "name": "死神",
      "upright": "",
      "reversed": ""
    },
    "14": {
      "name": "节制",
      "upright": "",
      "reversed": ""
    },
    "15": {
      "name": "恶魔",
      "upright": "",
      "reversed": ""
    },
    "16": {
      "name": "高塔",
      "upright": "",
      "reversed": ""
    },
    "17": {
      "name": "星辰",
      "upright": "",
      "reversed": ""
    },
    "18": {
      "name": "月亮",
      "upright": "",
      "reversed": ""
    },
    "19": {
      "name": "太阳",
      "upright": "",
      "reversed": ""
    },
    "20": {
      "name": "审判",
      "upright": "",
      "reversed": ""
    },
    "21": {
      "name": "世界",
      "upright": "",
      "reversed": ""
    }
  }
};
