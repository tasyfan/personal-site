window.DEFENSE_DATA = {
  "questions": [
    {
      "id": 1,
      "text": "当我看自己内心对某人产生强烈的不满或嫉妒时，我常觉得实际上是对方在处处针对和讨厌我。",
      "trait": "projection",
      "invert": false
    },
    {
      "id": 2,
      "text": "当我在某次竞争或考试中遭遇失败时，我能迅速列举出一大堆客观理由，证明这并不是我能力的问题。",
      "trait": "rationalization",
      "invert": false
    },
    {
      "id": 3,
      "text": "当面临巨大的成人生活或工作重压时，我会突然渴望像小孩子一样撒娇、哭闹，以此来逃避现实。",
      "trait": "regression",
      "invert": false
    },
    {
      "id": 4,
      "text": "当我内心极其厌恶或反感某个人时，为了显得得体，我反而会表现得对他格外热情与周到。",
      "trait": "formation",
      "invert": false
    },
    {
      "id": 5,
      "text": "即使现实证据已经摆在眼前，我依然倾向于认为那些糟糕的事情（如分手、危机）不太会发生在我身上。",
      "trait": "denial",
      "invert": false
    },
    {
      "id": 6,
      "text": "每当我内心感到压抑或愤怒时，我喜欢通过拼命运动、打扫房间或进行疯狂的艺术创作来宣泄精力。",
      "trait": "sublimation",
      "invert": false
    },
    {
      "id": 7,
      "text": "我常觉得身边的人对我充满防备和恶意，但我很少反思是不是我自己先对他们怀有敌意。",
      "trait": "projection",
      "invert": false
    },
    {
      "id": 8,
      "text": "当一段我很看重的感情破裂时，我会安慰自己说“这只是因为我们不合适，其实我早就不爱了”。",
      "trait": "rationalization",
      "invert": false
    },
    {
      "id": 9,
      "text": "当事情搞砸、面临惩罚时，我习惯用装病、赌气不吃饭或发脾气来博取家属或伴侣的妥协。",
      "trait": "regression",
      "invert": false
    },
    {
      "id": 10,
      "text": "我极力向外展示自己温柔、不争不抢的道德形象，哪怕我内心其实充满对权力和名利的渴望。",
      "trait": "formation",
      "invert": false
    },
    {
      "id": 11,
      "text": "在面对至亲离去或突发灾难时，我大脑会一片空白，在相当长的时间里照常生活，假装什么都没发生。",
      "trait": "denial",
      "invert": false
    },
    {
      "id": 12,
      "text": "我习惯将生活中的挫败和多余的精力，转化为工作上的极度拼搏，用加班和赚钱来填补内心的空虚。",
      "trait": "sublimation",
      "invert": false
    },
    {
      "id": 13,
      "text": "我觉得周围人经常在背后议论和挑剔我的缺点，虽然其实是我内心深处在嫌弃和挑剔他们。",
      "trait": "projection",
      "invert": false
    },
    {
      "id": 14,
      "text": "当我未能实现既定目标时，我往往会说这其实是塞翁失马，或者这个目标本来就毫无意义。",
      "trait": "rationalization",
      "invert": false
    },
    {
      "id": 15,
      "text": "面对巨大的社交压力或难堪的对话，我会本能地像孩子一样躲在自己的小角落里生闷气、不理人。",
      "trait": "regression",
      "invert": false
    },
    {
      "id": 16,
      "text": "当我非常嫉妒某位同事或朋友的成功时，我反而会加倍在公共场合热烈祝贺并赞美他。",
      "trait": "formation",
      "invert": false
    },
    {
      "id": 17,
      "text": "面对生活中那些我无法接受的沉重挫折或损失，我常会假装这一切只是个荒诞的梦，选择性地遗忘它。",
      "trait": "denial",
      "invert": false
    },
    {
      "id": 18,
      "text": "当我看不到希望或被压抑时，我往往会把全部精力投身于志愿者活动、学术研究或写日记中。",
      "trait": "sublimation",
      "invert": false
    },
    {
      "id": 19,
      "text": "当我感觉某人对我态度冷淡时，我坚信是他们心怀不轨，而不是因为我先冷落了他们。",
      "trait": "projection",
      "invert": false
    },
    {
      "id": 20,
      "text": "当我买了一件昂贵但无用的东西后，我会说服自己这是为了提升生活质量所必需的合理消费。",
      "trait": "rationalization",
      "invert": false
    },
    {
      "id": 21,
      "text": "当在工作中遭到批评时，我会非常渴望回到老家父母的怀抱，甚至想放弃所有的职业责任。",
      "trait": "regression",
      "invert": false
    },
    {
      "id": 22,
      "text": "当我对某人的傲慢感到极度恶心时，我会在见到他时表现得格外热情，并拼命寻找夸奖他的词汇。",
      "trait": "formation",
      "invert": false
    },
    {
      "id": 23,
      "text": "面对身体出现的慢性疾病信号，我习惯拖延看医生的时间，心想只要不去检查，身体就是健康的。",
      "trait": "denial",
      "invert": false
    },
    {
      "id": 24,
      "text": "当生活压力大到顶点时，我习惯去做一次彻底的大扫除，或者疯狂做饭，以此来转移内心的焦虑。",
      "trait": "sublimation",
      "invert": false
    },
    {
      "id": 25,
      "text": "我常常觉得伴侣在刻意隐瞒秘密或背叛我，即使这些担心大部分只是我自己内心欲望的投射。",
      "trait": "projection",
      "invert": false
    },
    {
      "id": 26,
      "text": "每次恋爱失败，我都能写出长篇大论的心理学理论来合理化这段感情的破裂，假装自己非常洒脱。",
      "trait": "rationalization",
      "invert": false
    },
    {
      "id": 27,
      "text": "当和伴侣发生争吵感到委屈时，我会摔门而出，像个任性的小孩一样关掉手机，让对方找不到我。",
      "trait": "regression",
      "invert": false
    },
    {
      "id": 28,
      "text": "我极力掩饰自己内心的不安和脆弱，反而在别人面前表现得极其强势和自信满满。",
      "trait": "formation",
      "invert": false
    },
    {
      "id": 29,
      "text": "即使财务状况已经亮起红灯，我仍然会在网购时假装看不见信用卡账单，照常进行非理性的消费。",
      "trait": "denial",
      "invert": false
    },
    {
      "id": 30,
      "text": "每当我在社交中感到屈辱或愤怒时，我更喜欢把这种力气用在写作、设计或更努力的学习上。",
      "trait": "sublimation",
      "invert": false
    },
    {
      "id": 31,
      "text": "每当我对家庭中的某个成员感到不耐烦时，我总觉得是他故意表现得令人讨厌来惹我生气。",
      "trait": "projection",
      "invert": false
    },
    {
      "id": 32,
      "text": "错失了某个极好的升职或发财机会后，我会反复告诉自己那只是个消耗人的苦差事，没拿到反而是好事。",
      "trait": "rationalization",
      "invert": false
    },
    {
      "id": 33,
      "text": "面对繁重的工作任务或客户刁难时，我会极度渴望立刻请假回家睡觉，像小孩子一样逃避所有义务。",
      "trait": "regression",
      "invert": false
    },
    {
      "id": 34,
      "text": "面对那个抢了我项目或伴侣的人，我反而会在公开场合表现得格外真诚，大方为他送上最热烈的祝福。",
      "trait": "formation",
      "invert": false
    },
    {
      "id": 35,
      "text": "即使财务账单已经赤字累累，我依然能照常消费，假装这些欠款并不会对我的长远生活产生实质性影响。",
      "trait": "denial",
      "invert": false
    },
    {
      "id": 36,
      "text": "每次失恋或感情遭遇巨大危机时，我通常会把所有精力和情绪都倾注在疯狂学习、码字或跑马拉松上。",
      "trait": "sublimation",
      "invert": false
    },
    {
      "id": 37,
      "text": "在职场中，我习惯认为同事都在暗地里竞争和嫉妒我，虽然其实是我对他们的成就有强烈的攀比心。",
      "trait": "projection",
      "invert": false
    },
    {
      "id": 38,
      "text": "当工作没能在规定时间内完成既定目标时，我总能从当前的经济形势或合作伙伴身上找到合理的脱罪借口。",
      "trait": "rationalization",
      "invert": false
    },
    {
      "id": 39,
      "text": "在恋爱关系中遇到无法解决的争执时，我习惯性地会通过长时间不吃东西或情绪崩溃来让对方妥协。",
      "trait": "regression",
      "invert": false
    },
    {
      "id": 40,
      "text": "即使我内心对某个虚伪的应酬场合厌恶透顶，我也能表现出全场最得体、最热情的笑容和寒暄。",
      "trait": "formation",
      "invert": false
    },
    {
      "id": 41,
      "text": "面对身体已经持续亮起的黄灯，我依然认为这只是暂时的疲惫，拒绝前往医院做全面的体检。",
      "trait": "denial",
      "invert": false
    },
    {
      "id": 42,
      "text": "每当我内心感到深深的压抑和虚无时，我习惯通过把房间收拾得一尘不染，或做一顿丰盛的食物来宣泄。",
      "trait": "sublimation",
      "invert": false
    },
    {
      "id": 43,
      "text": "我常觉得朋友对我的赞美不够真诚，带着某种防备，即使这只是我自己内心防备的镜子。",
      "trait": "projection",
      "invert": false
    },
    {
      "id": 44,
      "text": "如果我在社交聚会中被大家冷落，我会对自己说“我只是懒得融入这些平庸的低质社交罢了”。",
      "trait": "rationalization",
      "invert": false
    },
    {
      "id": 45,
      "text": "当遇到困难无人帮助时，我会表现出极度的软弱和无助，躺在床上一动不动，期盼有人来主动接管我。",
      "trait": "regression",
      "invert": false
    },
    {
      "id": 46,
      "text": "当我内心产生极端的自私想法时，我反而会刻意去展现出一种绝对大度、甚至有些圣人般的无私做派。",
      "trait": "formation",
      "invert": false
    },
    {
      "id": 47,
      "text": "伴侣的态度已经明显变冷，我依然能在微信聊天里给自己洗脑，认为对方只是一时工作太忙。",
      "trait": "denial",
      "invert": false
    },
    {
      "id": 48,
      "text": "我擅长把工作压力转化为个人成长和学习新技能的动力，是同事眼里的劳模，虽然其实我只是在逃避空虚。",
      "trait": "sublimation",
      "invert": false
    },
    {
      "id": 49,
      "text": "每次遇到沟通不顺，我本本能地觉得对方是在故意冷落或惩罚我，完全不考虑是不是自己先摆了脸色。",
      "trait": "projection",
      "invert": false
    },
    {
      "id": 50,
      "text": "每当我在亲密关系里退缩，我都会安慰自己说这只是为了给彼此留出空间，而不是因为我不敢承担责任。",
      "trait": "rationalization",
      "invert": false
    },
    {
      "id": 51,
      "text": "遭遇挫折后，我容易退回到疯狂打游戏、吃零食的状态中，以此来逃避现实世界的成人竞争。",
      "trait": "regression",
      "invert": false
    },
    {
      "id": 52,
      "text": "我极力掩饰自己内心的不安和自卑，为了不被看穿，反而在日常社交中表现得极具攻击性和高傲。",
      "trait": "formation",
      "invert": false
    },
    {
      "id": 53,
      "text": "每次遭遇重大的现实损失时，我大脑的第一反应是“这不是真的，这不可能发生在我身上”，并在相当长的时间里拒绝面对。",
      "trait": "denial",
      "invert": false
    },
    {
      "id": 54,
      "text": "当我对社会的某些现象感到极度愤怒时，我喜欢通过写长篇分析、画画或创作音乐来化解这些负面能量。",
      "trait": "sublimation",
      "invert": false
    },
    {
      "id": 55,
      "text": "我时常警告朋友不要有自私的想法，即便是我自己潜意识里在极其计较利益得失。",
      "trait": "projection",
      "invert": false
    },
    {
      "id": 56,
      "text": "没能通过某项资格认证或考试时，我往往会对别人说“这个证书在当下的含金量早已大不如前”。",
      "trait": "rationalization",
      "invert": false
    },
    {
      "id": 57,
      "text": "只要在生活中感到不顺心，我就会用任性赌气、拒不沟通的幼稚方式来向身边的人表达抗议。",
      "trait": "regression",
      "invert": false
    },
    {
      "id": 58,
      "text": "每当我想大发雷霆时，为了维护体面的外表，我反而会用极其温柔且冰冷的礼貌语气和对方交谈。",
      "trait": "formation",
      "invert": false
    },
    {
      "id": 59,
      "text": "哪怕身边的朋友都劝我及时止损，我依然能坚定地假装一切都很好，继续维持消耗自己的关系或工作。",
      "trait": "denial",
      "invert": false
    },
    {
      "id": 60,
      "text": "相比于找朋友倾诉，我更倾向于在深夜把所有的郁闷、挣扎都写进文学小说或专业分析文章里。",
      "trait": "sublimation",
      "invert": false
    }
  ],
  "profiles": {
    "projection": {
      "name": "投射机制防线",
      "desc": "你容易把自己暂时难以接纳的感受投射到外界，因此需要练习区分事实和猜测。",
      "deep": ""
    },
    "rationalization": {
      "name": "合理化机制防线",
      "desc": "你很擅长为选择找到解释，也需要练习区分真实理由和保护自尊的说法。",
      "deep": ""
    },
    "regression": {
      "name": "退行机制防线",
      "desc": "当压力过大时，你可能会退回更熟悉、更需要被照顾的表达方式。",
      "deep": ""
    },
    "formation": {
      "name": "反向形成防线",
      "desc": "你可能会用过度正确或过度体贴的外在表现，压住内心不容易承认的真实感受。",
      "deep": ""
    },
    "denial": {
      "name": "否认机制防线",
      "desc": "你会先把难以承受的事实放到一边，用暂时的平静保护自己。",
      "deep": ""
    },
    "sublimation": {
      "name": "升华机制防线",
      "desc": "你擅长把压力转化为行动和作品，但也需要给情绪本身留出被照顾的空间。",
      "deep": ""
    }
  }
};
