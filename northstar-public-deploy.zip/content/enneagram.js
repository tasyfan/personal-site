window.ENNEAGRAM_DATA = {
  "questions": [
    {
      "id": 1,
      "text": "我对自己的要求极高，当看到事情没有被正确地完成时，我会感到非常如鲠在喉。",
      "trait": "type1",
      "invert": false
    },
    {
      "id": 2,
      "text": "我极其热衷于感知并满足别人的需求，甚至常常因此忽略了自己的疲惫。",
      "trait": "type2",
      "invert": false
    },
    {
      "id": 3,
      "text": "我极度看重效率和目标，无法忍受任何阻碍我迈向成功的低效人际互动。",
      "trait": "type3",
      "invert": false
    },
    {
      "id": 4,
      "text": "我常感到自己与周围的人格格不入，内心深处有一种难以言说的孤独与特殊感。",
      "trait": "type4",
      "invert": false
    },
    {
      "id": 5,
      "text": "在卷入行动或社交之前，我习惯先退后一步，冷静地观察、收集信息并思考原理。",
      "trait": "type5",
      "invert": false
    },
    {
      "id": 6,
      "text": "我时刻在提防潜在的危机与变故，对我来说确认规则、盟友和安全感是最首要的。",
      "trait": "type6",
      "invert": false
    },
    {
      "id": 7,
      "text": "我极力让自己处于快乐与新鲜的体验中，抗拒任何沉闷、重复或压抑的环境。",
      "trait": "type7",
      "invert": false
    },
    {
      "id": 8,
      "text": "我不害怕任何形式的冲突或对抗，为了保护我的边界或弱小，我敢于直接挑战权威。",
      "trait": "type8",
      "invert": false
    },
    {
      "id": 9,
      "text": "我倾向于顺从别人的意愿来维持和谐，害怕激烈的争吵和关系被打破。",
      "trait": "type9",
      "invert": false
    },
    {
      "id": 10,
      "text": "当规则被打破或有人行事不公时，我内心会涌起强烈的愤怒，并试图纠正它。",
      "trait": "type1",
      "invert": false
    },
    {
      "id": 11,
      "text": "我害怕别人觉得我自私或疏离，因此常常难以拒绝别人的请求。",
      "trait": "type2",
      "invert": false
    },
    {
      "id": 12,
      "text": "我习惯用成就、头衔或外界的赞美来包装自己，以此证明我过得比别人好。",
      "trait": "type3",
      "invert": false
    },
    {
      "id": 13,
      "text": "我追求纯粹且充满艺术感的情感共鸣，讨厌虚伪和平庸的日常谈话。",
      "trait": "type4",
      "invert": false
    },
    {
      "id": 14,
      "text": "我不喜欢情绪化的依赖，宁愿在精神世界里独自探索，也不愿过多被他人打扰。",
      "trait": "type5",
      "invert": false
    },
    {
      "id": 15,
      "text": "在面对重大的决策时，我总是反复推敲利弊，充满焦虑，很难轻易下定决心。",
      "trait": "type6",
      "invert": false
    },
    {
      "id": 16,
      "text": "当事情变得复杂或痛苦时，我习惯用讲笑话或转换目标来逃避沉重的感觉。",
      "trait": "type7",
      "invert": false
    },
    {
      "id": 17,
      "text": "对我来说，掌控全局的节奏至关重要，我无法忍受处于被动或被他人支配的地位。",
      "trait": "type8",
      "invert": false
    },
    {
      "id": 18,
      "text": "我宁愿隐藏自己的主张和负面情绪，也不想惹麻烦或成为破坏氛围的罪人。",
      "trait": "type9",
      "invert": false
    },
    {
      "id": 19,
      "text": "当事情偏离了计划，或者有人偷懒怠工，我会非常难以忍受。",
      "trait": "type1",
      "invert": false
    },
    {
      "id": 20,
      "text": "在关心别人时，我总能轻易说出鼓励和赞美的话，但自己却很少向他人寻求帮助。",
      "trait": "type2",
      "invert": false
    },
    {
      "id": 21,
      "text": "在做决策或展示方案时，我总是先考虑怎样做才能显得最有成效、最成功。",
      "trait": "type3",
      "invert": false
    },
    {
      "id": 22,
      "text": "我常常会在艺术、音乐或文字的凄美感中找到共鸣，甚至享受这种淡淡的忧伤。",
      "trait": "type4",
      "invert": false
    },
    {
      "id": 23,
      "text": "对于复杂的人际情感纠葛，我本能地感到不知所措，更喜欢在纯理智或学术的领域寻找安全感。",
      "trait": "type5",
      "invert": false
    },
    {
      "id": 24,
      "text": "在与新朋友建立信任之前，我会本能地持怀疑态度，防备任何潜在的欺骗或被抛弃的可能。",
      "trait": "type6",
      "invert": false
    },
    {
      "id": 25,
      "text": "我喜欢让自己的日程表被各种新鲜有趣的计划填满，极其害怕生活陷入平庸和静止。",
      "trait": "type7",
      "invert": false
    },
    {
      "id": 26,
      "text": "如果有人挑战我的掌控权，或者行事虚伪懦弱，我会感到强烈的愤怒并直接给予对抗。",
      "trait": "type8",
      "invert": false
    },
    {
      "id": 27,
      "text": "为了避免与伴侣或团队发生任何摩擦，我往往会选择妥协，隐瞒自己真实的想法。",
      "trait": "type9",
      "invert": false
    },
    {
      "id": 28,
      "text": "我对细微的错误有近乎自动的敏锐，哪怕是一封邮件的错别字也会让我非常不舒服。",
      "trait": "type1",
      "invert": false
    },
    {
      "id": 29,
      "text": "我常常通过赠送礼物、提供实质帮助来确认别人对我的喜爱和认可。",
      "trait": "type2",
      "invert": false
    },
    {
      "id": 30,
      "text": "在社交聚会中，我会有意无意地透露自己的成功经历或高光时刻。",
      "trait": "type3",
      "invert": false
    },
    {
      "id": 31,
      "text": "我很容易沉溺在忧郁或哀伤的情绪中，觉得这种状态有一种独特的艺术美感。",
      "trait": "type4",
      "invert": false
    },
    {
      "id": 32,
      "text": "在参加社交活动之前，我需要准备充足的精神电量，否则会感到极度被掏空。",
      "trait": "type5",
      "invert": false
    },
    {
      "id": 33,
      "text": "我非常看重团队的忠诚度，一旦发现有人有背叛或不合群的苗头，我会高度警惕。",
      "trait": "type6",
      "invert": false
    },
    {
      "id": 34,
      "text": "当计划被取消或被局限在无聊的环境中时，我会立刻寻找其他刺激来填补空缺。",
      "trait": "type7",
      "invert": false
    },
    {
      "id": 35,
      "text": "当我看到不公义的事情发生时，哪怕跟我无关，我也会选择站出来对抗强者。",
      "trait": "type8",
      "invert": false
    },
    {
      "id": 36,
      "text": "我常常觉得别人的矛盾或争吵会吸干我的能量，宁可物理逃避也不想做裁判。",
      "trait": "type9",
      "invert": false
    },
    {
      "id": 37,
      "text": "当看到别人做事敷衍了事、降低标准时，我会忍不住指责或自己接手。",
      "trait": "type1",
      "invert": false
    },
    {
      "id": 38,
      "text": "哪怕别人明确拒绝了我的帮助，我也会忍不住继续为他们操心和打点。",
      "trait": "type2",
      "invert": false
    },
    {
      "id": 39,
      "text": "为了达到事业或学习的目标，我常常压抑自己真实的疲惫和情绪需求。",
      "trait": "type3",
      "invert": false
    },
    {
      "id": 40,
      "text": "我对世俗的流行趋势和大众审美持保留态度，必须穿搭或表达出自己的与众不同。",
      "trait": "type4",
      "invert": false
    },
    {
      "id": 41,
      "text": "我宁愿在网上查找海量资料研究一个问题，也不愿意直接去请教现实中的人。",
      "trait": "type5",
      "invert": false
    },
    {
      "id": 42,
      "text": "在进入陌生环境时，我会先观察逃生通道或制定兜底的安全备用计划。",
      "trait": "type6",
      "invert": false
    },
    {
      "id": 43,
      "text": "我宁愿有很多未完成的半吊子兴趣，也不愿意在一件事上感到沉闷和被困住。",
      "trait": "type7",
      "invert": false
    },
    {
      "id": 44,
      "text": "我极力避免在别人面前展现脆弱或流泪，因为在我看来那意味着被掌控。",
      "trait": "type8",
      "invert": false
    },
    {
      "id": 45,
      "text": "很多时候我并不是没有意见，只是觉得说出不同意见会引发争执，太麻烦了。",
      "trait": "type9",
      "invert": false
    },
    {
      "id": 46,
      "text": "当发现流程或规则中存在逻辑漏洞时，我会感到如鲠在喉，必须予以纠正。",
      "trait": "type1",
      "invert": false
    },
    {
      "id": 47,
      "text": "我非常享受那种被他人依赖、视我为避风港的情感连结。",
      "trait": "type2",
      "invert": false
    },
    {
      "id": 48,
      "text": "我认为平庸是一种隐形的失败，人生必须要不断取得瞩目的成绩。",
      "trait": "type3",
      "invert": false
    },
    {
      "id": 49,
      "text": "我常常觉得没有人能真正触及我内心深处那片复杂的哀伤与诗意。",
      "trait": "type4",
      "invert": false
    },
    {
      "id": 50,
      "text": "当面对纷繁复杂的情感冲突时，我的本能反应是退缩并用理智去冷眼旁观。",
      "trait": "type5",
      "invert": false
    },
    {
      "id": 51,
      "text": "我习惯于在事情开始前就设想出最坏的防备方案，以此来抵御未知的风险。",
      "trait": "type6",
      "invert": false
    },
    {
      "id": 52,
      "text": "当生活变得一成不变时，我会感到强烈的压力变大感，必须立刻寻找新乐子。",
      "trait": "type7",
      "invert": false
    },
    {
      "id": 53,
      "text": "我相信真理和力量掌握在敢于抗争的人手中，绝不向强权或不公低头。",
      "trait": "type8",
      "invert": false
    },
    {
      "id": 54,
      "text": "我常常觉得很多争执都是无意义的，宁愿自己吃点亏也要换来大家相安无事。",
      "trait": "type9",
      "invert": false
    },
    {
      "id": 55,
      "text": "我时常会因为自己没有达到预期的道德或行为标准而产生强烈的内疚感。",
      "trait": "type1",
      "invert": false
    },
    {
      "id": 56,
      "text": "当我所关心的人表现出冷淡或疏远时，我会感到极度的不安与委屈。",
      "trait": "type2",
      "invert": false
    },
    {
      "id": 57,
      "text": "我很擅长在不同的社交场合快速转换人设，以展现出最受欢迎的形象。",
      "trait": "type3",
      "invert": false
    },
    {
      "id": 58,
      "text": "我极度排斥随大流，宁愿特立独行被视作怪人，也不愿变得平庸无奇。",
      "trait": "type4",
      "invert": false
    },
    {
      "id": 59,
      "text": "我对个人时间和私密空间有极高的要求，任何无端的打扰都会让我感到被侵犯。",
      "trait": "type5",
      "invert": false
    },
    {
      "id": 60,
      "text": "我对权威和规则持有一种复杂的怀疑态度，既想要依赖，又害怕被控制。",
      "trait": "type6",
      "invert": false
    },
    {
      "id": 61,
      "text": "我习惯把沉重、悲伤的谈话用幽默轻松带过，讨厌沉溺在痛苦的氛围里。",
      "trait": "type7",
      "invert": false
    },
    {
      "id": 62,
      "text": "我对懦弱和推诿塞责的行为深恶痛绝，宁可自己承担所有责任直接硬碰硬。",
      "trait": "type8",
      "invert": false
    },
    {
      "id": 63,
      "text": "当别人让我做决定时，我的本能反应是“随便、都行”，以此避免产生分歧。",
      "trait": "type9",
      "invert": false
    },
    {
      "id": 64,
      "text": "对我而言，按时、按质、按量完成承诺是做人的底线，无法容忍拖延。",
      "trait": "type1",
      "invert": false
    },
    {
      "id": 65,
      "text": "我常常会主动承担团队中的情感调解工作，希望能让每个人都感到被温暖。",
      "trait": "type2",
      "invert": false
    },
    {
      "id": 66,
      "text": "即使内心十分疲惫，我也会在公开场合保持高昂的斗志和完美的精力。",
      "trait": "type3",
      "invert": false
    },
    {
      "id": 67,
      "text": "当觉得自己不被理解时，我会主动切断与周围世界的联系，享受孤独。",
      "trait": "type4",
      "invert": false
    },
    {
      "id": 68,
      "text": "我宁愿花几天时间独立钻研底层技术原理，也不想直接向专家索要答案。",
      "trait": "type5",
      "invert": false
    },
    {
      "id": 69,
      "text": "当环境发生剧烈变动时，我会高度戒备，反复评估身边人的可信赖程度。",
      "trait": "type6",
      "invert": false
    },
    {
      "id": 70,
      "text": "我的大脑里永远有十几个待办的有趣计划，哪怕很多最后都无法真正落地。",
      "trait": "type7",
      "invert": false
    },
    {
      "id": 71,
      "text": "我本能地想要掌控所处环境的主导权，无法忍受在别人的规则下委曲求全。",
      "trait": "type8",
      "invert": false
    },
    {
      "id": 72,
      "text": "我倾向于用拖延或假装看不见的方式来处理棘手的矛盾，希望时间能冲淡一切。",
      "trait": "type9",
      "invert": false
    },
    {
      "id": 73,
      "text": "我习惯在做任何事情前都制定严密的步骤，并期待他人也能遵照执行。",
      "trait": "type1",
      "invert": false
    },
    {
      "id": 74,
      "text": "为了不让别人失望，我常常会超出能力范围地答应各种请求。",
      "trait": "type2",
      "invert": false
    },
    {
      "id": 75,
      "text": "我习惯用可量化的指标（如收入、头衔、粉丝数）来评估自己的社会价值。",
      "trait": "type3",
      "invert": false
    },
    {
      "id": 76,
      "text": "我很容易被那些带有悲剧色彩的美感所打动，觉得不完整也比完美更真实。",
      "trait": "type4",
      "invert": false
    },
    {
      "id": 77,
      "text": "情感表达对我来说是一件消耗能量的事，我更喜欢用理智的观点进行交流。",
      "trait": "type5",
      "invert": false
    },
    {
      "id": 78,
      "text": "我非常看重规章制度和安全边界，觉得没有边界的自由意味着巨大的危险。",
      "trait": "type6",
      "invert": false
    },
    {
      "id": 79,
      "text": "我倾向于只看事物的阳光面，相信所有的困境都可以被乐观的创意所解构。",
      "trait": "type7",
      "invert": false
    },
    {
      "id": 80,
      "text": "保护弱小是我的本能，哪怕因此把自己推向冲突的最前线也在所不惜。",
      "trait": "type8",
      "invert": false
    },
    {
      "id": 81,
      "text": "激烈的争吵和不和谐的氛围会迅速榨干我的能量，让我只想身体逃避。",
      "trait": "type9",
      "invert": false
    },
    {
      "id": 82,
      "text": "即使在放松娱乐时，我也常常会不自觉地纠正身边的混乱和无序。",
      "trait": "type1",
      "invert": false
    },
    {
      "id": 83,
      "text": "潜意识里，我常常觉得如果我不去照顾别人，我就失去了存在的价值。",
      "trait": "type2",
      "invert": false
    },
    {
      "id": 84,
      "text": "当被别人超越时，我会涌起强烈的竞争欲，并加倍努力以重新夺回优势。",
      "trait": "type3",
      "invert": false
    },
    {
      "id": 85,
      "text": "我习惯于在脑海中不断回味过往的遗憾，觉得那种痛楚能证明我的存在。",
      "trait": "type4",
      "invert": false
    },
    {
      "id": 86,
      "text": "在卷入行动前，我需要收集足够的信息，确保局势完全在我的心智掌控中。",
      "trait": "type5",
      "invert": false
    },
    {
      "id": 87,
      "text": "在做决定时，我往往需要反复向信任的伙伴或导师求证，才能消除内心的疑虑。",
      "trait": "type6",
      "invert": false
    },
    {
      "id": 88,
      "text": "我极力避免做出长期的、死板的承诺，因为那会限制我体验其他可能的自由。",
      "trait": "type7",
      "invert": false
    },
    {
      "id": 89,
      "text": "在遭遇背叛或攻击时，我的第一反应是发起雷霆般的反击，而不是息事宁人。",
      "trait": "type8",
      "invert": false
    },
    {
      "id": 90,
      "text": "我很容易顺应环境和团队的节奏，甚至常常因此忘记了自己最真实的渴望。",
      "trait": "type9",
      "invert": false
    }
  ],
  "profiles": {
    "type1": {
      "name": "完美主义者",
      "desc": "你重视秩序、责任和正确性，也容易把标准同时放在自己和他人身上。",
      "deep": ""
    },
    "type2": {
      "name": "渴望被爱的助人者",
      "desc": "你很擅长照顾他人，也需要确认付出背后是否隐藏着被需要的期待。",
      "deep": ""
    },
    "type3": {
      "name": "戴着面具的成就者",
      "desc": "你擅长达成目标和呈现成果，也需要练习在表现之外看见真实的自己。",
      "deep": ""
    },
    "type4": {
      "name": "沉溺悲剧的艺术家",
      "desc": "你对独特性和情感深度很敏锐，也需要把灵感安放回稳定的日常里。",
      "deep": ""
    },
    "type5": {
      "name": "孤岛之上的理智者",
      "desc": "你习惯先用知识和逻辑保持距离，也需要为真实互动留出空间。",
      "deep": ""
    },
    "type6": {
      "name": "提防一切的忠诚者",
      "desc": "你对风险很敏感，擅长提前准备，也需要练习把注意力从危险转向资源。",
      "deep": ""
    },
    "type7": {
      "name": "贪婪体验的活跃者",
      "desc": "你擅长发现可能性和制造轻松感，也需要练习停下来面对真实需要。",
      "deep": ""
    },
    "type8": {
      "name": "坚硬如铁的领袖者",
      "desc": "你习惯用力量和掌控保护自己，也需要允许柔软被信任的人看见。",
      "deep": ""
    },
    "type9": {
      "name": "随波逐流的和平者",
      "desc": "你很会维持关系平和，也需要练习把自己的立场和需要说清楚。",
      "deep": ""
    }
  }
};
