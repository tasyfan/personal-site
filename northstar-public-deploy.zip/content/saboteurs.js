window.SABOTEURS_DATA = {
  "questions": [
    {
      "id": 1,
      "text": "如果事情不完全在我的指挥或掌控之下，我会感到强烈的焦虑和不安。",
      "trait": "controller",
      "invert": false
    },
    {
      "id": 2,
      "text": "我习惯通过拼命满足别人的需要来博取认可，当他们表现冷淡时，我内心会充满委屈。",
      "trait": "pleaser",
      "invert": false
    },
    {
      "id": 3,
      "text": "我对细节和秩序有着近乎过度的严苛要求，如果看到一丝不完美，我会感到难以忍受。",
      "trait": "stickler",
      "invert": false
    },
    {
      "id": 4,
      "text": "面对情感冲突时，我倾向于关闭情绪电量，用冰冷、客观的逻辑去解构和敷衍对方。",
      "trait": "rational",
      "invert": false
    },
    {
      "id": 5,
      "text": "我常觉得命运对我极其不公，习惯沉浸在受伤、痛苦的情感深渊中来获得安慰与关注。",
      "trait": "victim",
      "invert": false
    },
    {
      "id": 6,
      "text": "在团队协作中，我很难放手将重要环节托付给别人，总想插手监督他们的每一个细节。",
      "trait": "controller",
      "invert": false
    },
    {
      "id": 7,
      "text": "我极度害怕因为对别人说“不”而招致他们的讨厌，经常委曲求全地接受各种无理请求。",
      "trait": "pleaser",
      "invert": false
    },
    {
      "id": 8,
      "text": "我宁愿无限期地拖延一个项目的启动，也绝不愿意提交一个可能存在一丝瑕疵的半成品。",
      "trait": "stickler",
      "invert": false
    },
    {
      "id": 9,
      "text": "我认为哭泣或过度流露脆弱是毫无用处的，这会导致我经常显得冷血、难以沟通。",
      "trait": "rational",
      "invert": false
    },
    {
      "id": 10,
      "text": "当困难来临时，我常下意识地表现出软弱或崩溃，期盼能有强者能主动来拯救或安抚我。",
      "trait": "victim",
      "invert": false
    },
    {
      "id": 11,
      "text": "如果局势或者身边的人脱离了我的掌控轨道，我会用强势、指责的态度来逼迫他们顺从。",
      "trait": "controller",
      "invert": false
    },
    {
      "id": 12,
      "text": "在人际交往中，我常常主动扮演“拯救者”或“开导者”，试图通过有用性来维持对方的重视。",
      "trait": "pleaser",
      "invert": false
    },
    {
      "id": 13,
      "text": "我会花大把时间去纠结一些对大局毫无影响的微小细节，这极大地拖垮了我的行动效率。",
      "trait": "stickler",
      "invert": false
    },
    {
      "id": 14,
      "text": "我喜欢和人探讨深刻的理论，但一旦涉及到深入的心理坦诚，我的第一反应是抽离和隔离。",
      "trait": "rational",
      "invert": false
    },
    {
      "id": 15,
      "text": "我经常向人倾诉我的种种受挫经历和痛苦感受，虽然我想解决问题，但更享受被同情的过程。",
      "trait": "victim",
      "invert": false
    },
    {
      "id": 16,
      "text": "当别人做事没有按照我的节奏或者方式进行时，我会本能地感到烦躁并想去强行干预。",
      "trait": "controller",
      "invert": false
    },
    {
      "id": 17,
      "text": "我常常因为害怕失去别人的喜爱，而压抑自己真实的负面情绪和不同意见。",
      "trait": "pleaser",
      "invert": false
    },
    {
      "id": 18,
      "text": "即使是一个非常简单的排版或格式错误，也会让我感到极度难受，非要立刻修改干净不可。",
      "trait": "stickler",
      "invert": false
    },
    {
      "id": 19,
      "text": "我觉得在讨论问题时掺杂太多的情绪化表达是毫无逻辑、非常低效且令人反感的。",
      "trait": "rational",
      "invert": false
    },
    {
      "id": 20,
      "text": "当事情不顺利时，我常觉得自己是命运最大的牺牲品，为什么受挫的偏偏总是我。",
      "trait": "victim",
      "invert": false
    },
    {
      "id": 21,
      "text": "当有人试图引导或干预我的生活决定时，我会非常反感并立刻开启防御。",
      "trait": "controller",
      "invert": false
    },
    {
      "id": 22,
      "text": "为了讨好伴侣或朋友，我愿意频繁牺牲自己的休息时间去迎合他们的活动安排。",
      "trait": "pleaser",
      "invert": false
    },
    {
      "id": 23,
      "text": "对自己和他人的高标准常常导致我做事紧绷，很难坦然接受生活中的一些意外混乱。",
      "trait": "stickler",
      "invert": false
    },
    {
      "id": 24,
      "text": "当别人情绪失控或向我哭诉时，我习惯从科学和理性角度客观剖析原因，而非提供安慰。",
      "trait": "rational",
      "invert": false
    },
    {
      "id": 25,
      "text": "我常常会夸大自己的伤痛或不顺利，以此来获得别人的理解、包容或特权。",
      "trait": "victim",
      "invert": false
    },
    {
      "id": 26,
      "text": "在家庭或亲密关系中，谁说了算对我来说是原则问题，我必须在主导地位。",
      "trait": "controller",
      "invert": false
    },
    {
      "id": 27,
      "text": "别人的一句叹息或不满的眼神都会让我紧张很久，心想是不是我刚才做错了什么。",
      "trait": "pleaser",
      "invert": false
    },
    {
      "id": 28,
      "text": "当看到工作伙伴的成果达不到我的严苛要求时，我会一边在心里埋怨，一边强行接管。",
      "trait": "stickler",
      "invert": false
    },
    {
      "id": 29,
      "text": "相比于虚无缥缈的直觉或热烈的情感流露，我只信任数据、逻辑和客观事实。",
      "trait": "rational",
      "invert": false
    },
    {
      "id": 30,
      "text": "在陷入生活低谷时，我容易沉溺于“自我同情”的哀伤中，提不起任何改变的力气。",
      "trait": "victim",
      "invert": false
    },
    {
      "id": 31,
      "text": "在开展一个项目时，我会不自觉地把决策权全部揽在自己手里，觉得别人做决定都不靠谱。",
      "trait": "controller",
      "invert": false
    },
    {
      "id": 32,
      "text": "我常常会为了迎合大家的共同话题，假装自己也喜欢某些我其实非常讨厌的东西。",
      "trait": "pleaser",
      "invert": false
    },
    {
      "id": 33,
      "text": "如果一件工作的排版、字体或线框没有达到我的审美标准，我会坚决拒绝提交。",
      "trait": "stickler",
      "invert": false
    },
    {
      "id": 34,
      "text": "听到别人讨论爱情、缘分或直觉等感性话题时，我会觉得非常荒谬且毫无逻辑。",
      "trait": "rational",
      "invert": false
    },
    {
      "id": 35,
      "text": "我常常会觉得周围的人都在故意针对我，把所有的生活挫折都归咎于环境的恶意。",
      "trait": "victim",
      "invert": false
    },
    {
      "id": 36,
      "text": "伴侣或朋友如果没有及时向我汇报他们的动向，我会感到被排除在外的强烈焦虑。",
      "trait": "controller",
      "invert": false
    },
    {
      "id": 37,
      "text": "在听到朋友对我的一点点微弱批评后，我会内耗很久，绞尽脑汁去想怎么修复形象。",
      "trait": "pleaser",
      "invert": false
    },
    {
      "id": 38,
      "text": "我对自己和身边人都有极其苛刻的准时要求，哪怕迟到一分钟也会让我非常火大。",
      "trait": "stickler",
      "invert": false
    },
    {
      "id": 39,
      "text": "面对情绪化的沟通，我习惯于开启“理智屏蔽模式”，只分析文字中的逻辑漏洞。",
      "trait": "rational",
      "invert": false
    },
    {
      "id": 40,
      "text": "沉溺于那种淡淡的忧伤与被命运遗弃的孤独感，有时候反而让我觉得内心很平静。",
      "trait": "victim",
      "invert": false
    },
    {
      "id": 41,
      "text": "我习惯于指导身边人如何做事，觉得这是在帮他们，但他们往往觉得我管得太宽。",
      "trait": "controller",
      "invert": false
    },
    {
      "id": 42,
      "text": "我总觉得如果不主动为别人做点什么，自己就成了不够体贴、不受欢迎的人。",
      "trait": "pleaser",
      "invert": false
    },
    {
      "id": 43,
      "text": "相比于追求突破和速度，我更倾向于在已知且安全的安全步骤内反复打磨细节。",
      "trait": "stickler",
      "invert": false
    },
    {
      "id": 44,
      "text": "我极少在别人面前表露哭泣或崩溃，因为我觉得那是非常软弱且无能的丢脸行为。",
      "trait": "rational",
      "invert": false
    },
    {
      "id": 45,
      "text": "当发生重大争执时，我习惯于用哭泣或身体不适来作为结束辩论的防御手段。",
      "trait": "victim",
      "invert": false
    },
    {
      "id": 46,
      "text": "看到事情偏离了我原定的计划轨道，即使只是微小的偏差，我也会立刻表现得非常有攻击性。",
      "trait": "controller",
      "invert": false
    },
    {
      "id": 47,
      "text": "即使自己已经疲惫不堪，只要别人开口求助，我还是会咬着牙撑下去帮他们做完。",
      "trait": "pleaser",
      "invert": false
    },
    {
      "id": 48,
      "text": "我常常会因为对自己做过的事情不放心，而在提交前反复检查十几次，极大地拖慢了效率。",
      "trait": "stickler",
      "invert": false
    },
    {
      "id": 49,
      "text": "相比于提供温暖的同情，我更倾向于直接给悲伤的朋友提几条实用的逻辑解决方案。",
      "trait": "rational",
      "invert": false
    },
    {
      "id": 50,
      "text": "我常对那些能轻松快乐地活着的人产生深深的嫉妒，觉得命运给了他们不公平的优待。",
      "trait": "victim",
      "invert": false
    }
  ],
  "profiles": {
    "controller": {
      "name": "控制型保护模式",
      "desc": "你倾向于通过掌控局面获得安全感，也需要练习把部分空间交还给他人。",
      "deep": ""
    },
    "pleaser": {
      "name": "迎合型保护模式",
      "desc": "你很擅长照顾他人，也需要确认自己的付出是否带着未说出口的期待。",
      "deep": ""
    },
    "stickler": {
      "name": "完美校准型保护模式",
      "desc": "你重视秩序和细节，也需要允许事情先以足够可用的状态落地。",
      "deep": ""
    },
    "rational": {
      "name": "超理智防御模式",
      "desc": "你习惯用理性保持稳定，也需要给真实感受留出表达位置。",
      "deep": ""
    },
    "victim": {
      "name": "受伤叙事型保护模式",
      "desc": "你容易停留在受伤叙事里，也需要把注意力逐步带回当下可行动的部分。",
      "deep": ""
    }
  }
};
