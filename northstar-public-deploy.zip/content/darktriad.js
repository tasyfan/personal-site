window.DARKTRIAD_DATA = {
  "questions": [
    {
      "id": 1,
      "text": "只要能够达到最终目的，使用一些操纵他人的欺骗手段对我来说是完全合理的。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 2,
      "text": "我天然地觉得自己是个特殊的人，理应得到比周围人更多的特权、关注与优待。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 3,
      "text": "我很少为他人的痛苦感到难过，有时甚至觉得他们落得如此下场完全是咎由自取。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 4,
      "text": "在卷入利益冲突时，我会冷静地隐藏自己的真实筹码，通过算计达到最大胜率。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 5,
      "text": "我喜欢成为舞台上的焦点，并极度渴望被他人羡慕、崇拜甚至嫉妒。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 6,
      "text": "我做事喜欢追求极端的刺激与冒险，就算这样做可能会伤害到他人的利益也在所不惜。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 7,
      "text": "大部分人都是愚蠢且容易被愚弄的，引导他们去配合我的计划只是一种合理利用。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 8,
      "text": "如果有人挑战了我的权威或面子，我会感到极度愤怒并一定要让他们付出代价。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 9,
      "text": "我不喜欢任何形式的道德规训，破坏规则甚至游走在法律边缘能带给我极大的兴奋感。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 10,
      "text": "为了保护我自己的绝对利益，我不介意随时切断与某人的关系或背弃承诺。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 11,
      "text": "我常觉得我身边的人都十分平庸，而我注定是要做出一番不平凡事业的。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 12,
      "text": "如果有人做错了事来向我道歉，我很难产生真正的同情，只觉得这种软弱非常无趣。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 13,
      "text": "为了确保自己在竞争中处于绝对主动，我常常会暗中挑拨对手之间的关系。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 14,
      "text": "当我进入一个房间，我坚信自己是最具魅力和智慧的那个人，别人理应对我报以关注。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 15,
      "text": "当看到别人由于自己的失误或轻信而哭泣时，我只觉得愚蠢，甚至隐约感到有些滑稽。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 16,
      "text": "我认为在利益面前，所谓的友情或商业信用都是随时可以根据性价比进行调整的。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 17,
      "text": "如果有人敢在公开场合指出我的不足，我一定会用最严厉的手段还击以维护尊严。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 18,
      "text": "越是危险、被社会禁止或充满争议的事情，越能点燃我内心深处的征服欲与快感。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 19,
      "text": "我擅长通过赞美和奉承来引导别人为我的利益服务，这不过是一种高超的交际技巧。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 20,
      "text": "我坚信普通人无法理解我的高维想法与志向，我只配和同等优秀的人交往。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 21,
      "text": "当有人被骗或遭受损失时，我会暗自嘲笑他们的单纯，而不会同情他们。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 22,
      "text": "如果提前透露真相会破坏我的计划，我会毫不犹豫地选择性隐瞒或撒谎。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 23,
      "text": "我非常喜欢向别人展示我的优秀成果、奢华消费或特殊成就，并享受他们崇拜的眼神。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 24,
      "text": "对暴力、血腥或高风险极限运动我没有任何恐惧感，甚至觉得这非常能激发斗志。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 25,
      "text": "所谓的人际关系本质上就是资源整合与价值互换，谁有筹码谁就拥有定义关系的权力。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 26,
      "text": "我无法容忍任何人忽视我的存在，哪怕只是在社交媒体上没有及时给我点赞。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 27,
      "text": "如果伤害别人能帮助我更快拿到我想要的东西，我几乎不会受到良心的谴责。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 28,
      "text": "在推进一项合作时，我会暗中搜集盟友的隐私或软肋，作为未来可能博弈的筹码。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 29,
      "text": "我时常觉得我的美学品味和思维深度远远超过了我周围的大多数人。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 30,
      "text": "对规则和禁忌有一种本能的挑衅欲，越是被禁止的行为，越能让我感到刺激。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 31,
      "text": "我习惯把所有的表态都留有余地，绝不轻易做出无法反悔的绝对承诺。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 32,
      "text": "我希望我的伴侣在任何时候都能以我的需求为中心，并能够随时赞美我。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 33,
      "text": "当我的行为伤害到他人的感情时，我内心其实毫无波动，甚至觉得是他们太脆弱。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 34,
      "text": "我非常懂得在不同的人面前说不同的话，这只是一种生存技能，谈不上欺骗。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 35,
      "text": "当团队取得成功时，我坚信我才是那个起到了决定性作用的灵魂人物。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 36,
      "text": "我很难专注做那些需要长期耐心深耕的事，更喜欢追求即时爆发的刺激与冒险。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 37,
      "text": "在利益受损的瞬间，我能迅速切断所有的同情与感性，冷静地计算如何将损失降到最低。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 38,
      "text": "我在公开场合分享自己的日常生活或工作成果时，习惯用最让人羡慕的方式进行包装。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 39,
      "text": "在面对极度危险、惊悚或高强度的压力情境时，我的心率几乎不会有任何变化。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 40,
      "text": "如果把秘密分享出去能换取更大的现实利益，我会毫不犹豫地选择透露。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 41,
      "text": "如果有人在工作中表现得比我更出风头，我会感到非常不适，并试图在其他方面压制他们。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 42,
      "text": "对传统的家庭观念或长期稳定的情感纽带没有太高兴趣，更喜欢随性自由。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 43,
      "text": "我相信在这个世界上，所谓的道德只是强者用来规训弱者的工具，没必要完全遵守。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 44,
      "text": "我坚信普通人生活极其乏味，而我所追求的生活理应充满质感、高级与特殊性。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 45,
      "text": "如果伤害一个人可以让我感到心情愉悦，我可能真的会去这么做，且不觉得愧疚。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 46,
      "text": "当我需要争取某人的支持时，我会刻意去迎合他们的喜好，即使我内心对此充满鄙视。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 47,
      "text": "当别人指出我的错误时，我的第一反应是他们由于嫉妒我而在刻意刁难。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 48,
      "text": "我认为所谓的“报应”和“因果”只是弱者的自我安慰，现实中只有强弱之分。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 49,
      "text": "在面对竞争对手的求助时，我会微笑着拒绝，甚至在暗中不动声色地加速他们的失败。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 50,
      "text": "我非常享受那种被众人环绕、被视作意见领袖或榜样的绝对瞩目感。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 51,
      "text": "做事从不考虑长远的后果，只求在当下的那一秒钟能够获得极致的畅快。",
      "trait": "psycho",
      "invert": false
    },
    {
      "id": 52,
      "text": "如果能让我彻底掌握局面的主导权，我不介意在背后利用一些信息差来误导周围的人。",
      "trait": "mach",
      "invert": false
    },
    {
      "id": 53,
      "text": "如果一个聚会或活动没有将我放在核心位置，我很快就会觉得这个活动毫无意义。",
      "trait": "narc",
      "invert": false
    },
    {
      "id": 54,
      "text": "当看到别人遭遇重大的天灾人祸时，我内心的第一感受是觉得有些滑稽，而不是同情。",
      "trait": "psycho",
      "invert": false
    }
  ],
  "profiles": {
    "mach": {
      "name": "马基雅维利主义倾向",
      "desc": "你在关系和合作中很重视策略与主动权，也需要留意防备过强带来的距离感。",
      "deep": ""
    },
    "narc": {
      "name": "自恋特质倾向",
      "desc": "你很在意被看见和被肯定，也需要建立不依赖外界掌声的稳定自我感。",
      "deep": ""
    },
    "psycho": {
      "name": "低共情冲动倾向",
      "desc": "你对高刺激体验更敏感，也需要练习在行动前多停一步确认边界和后果。",
      "deep": ""
    }
  }
};
